README FILE FOR ONLINE SHARES TRADING PROJECT
AUTHOR: JACOB HORGAN
DATE CREATED: 14.05.2020



PLEASE ENSURE THAT YOU HAVE INSTALLED THE FOLLOWING:

- pyfiglet



SEQUENCE OF FILE EXECUTION:

- Please Run project from the shares_start_file.py



FILE DESCRIPTIONS:

shares_start_file.py
- This file is used to intiate the project and runs the main loop

shares_navigation_file.py
- This file is used for the navigation of the project and displays relevant screens.
- It also calls functions from the Cash and Invest files.

shares_cash_file.py
- This file contains all of the functions that handle calculations regarding the 

shares_invest_file.py
- This file contains all of the functions that handle calculations regard the Cash Account.